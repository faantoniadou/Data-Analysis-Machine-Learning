#%%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#%%
inputData = pd.read_csv( 'output_nt_Energy.csv', comment='#', \
names=['TrueEnergy', 'Layer1', 'Layer2', 'Layer3', 'Layer4', 'Layer5'] )
print(inputData)

def calibrate():
    trueEnergy = inputData['TrueEnergy']  # shape array to multiply
    Edetected = inputData.iloc[:, -5:-1].sum(axis=1)                  # flatten dataframe and multiply, exclude first colmn
    
    calibrationValues = trueEnergy/Edetected               # find mean of fraction
    calibrationValue = np.mean(calibrationValues)

    CaliData = Edetected * calibrationValue
    DetRes = (CaliData - trueEnergy)/trueEnergy
     
    print(DetRes)
    #print(calibrationQuality)

    plt.hist2d( x=trueEnergy, y=DetRes, bins=(10, 20) )
    plt.ylabel('( Calibrated energy - true energy )/ true energy')
    plt.xlabel('True Energy [MeV]')
    plt.show()
    #plt.hist( DetRes, 10 )
    #plt.xlabel('( Calibrated energy - true energy )/ true energy')
    #plt.show()

calibrate()
# %%

# %%
